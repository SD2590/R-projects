loan <- read.csv("/resources/data/loan_data.csv")
str(loan)
summary(loan)

#Convert columns to factor as applicable
loan$not.fully.paid = as.factor(loan$not.fully.paid)
loan$pub.rec = as.factor(loan$pub.rec)
loan$delinq.2yrs = as.factor(loan$delinq.2yrs)
loan$inq.last.6mths = as.factor(loan$inq.last.6mths)
loan$credit.policy = as.factor(loan$credit.policy)

#EDA
library(ggplot2)

#Create a histogram of fico scores colored by not.fully.paid
ggplot(loan,aes(fico)) + geom_histogram(aes(fill=not.fully.paid),binwidth=5,color="black") + theme_bw()

#Create a barplot of purpose counts, colored by not.fully.paid
ggplot(loan,aes(purpose)) + geom_bar(aes(fill=factor(not.fully.paid)),position='dodge') + theme_bw() + theme(axis.text.x = element_text(angle = 45, hjust = 1))

#Create a scatterplot of fico score versus int.rate.
ggplot(loan,aes(int.rate,fico)) + geom_point(aes(color=not.fully.paid),alpha=0.4) + theme_bw()


#Build the model
library(caTools)
set.seed(101)
sample = sample.split(loan$not.fully.paid, SplitRatio = .70)
train = subset(loan, sample == TRUE)
test = subset(loan, sample == FALSE)

install.packages("e1071")
library(e1071)
model = svm(formula = not.fully.paid ~ ., data = train)
summary(model)

#Make predictions
prediction <- predict(model,test)
table(prediction,test$not.fully.paid)

#Tune results
tune.results <- tune(svm,train.x=not.fully.paid~., data=train,kernel='radial',
                     ranges=list(cost=c(1,5,10), gamma=c(0.1,1,1.5)))
tune.results

#Tuned model
model1 = svm(formula = not.fully.paid ~ ., data = train, cost=10, gamma=0.1)

prediction <- predict(model1,test)
table(prediction,test$not.fully.paid)
