library("ggplot2", lib.loc="/usr/local/lib/R/site-library")
install.packages('ggplot2movies')
library("ggplot2movies", lib.loc="/resources/common/R/Library")

#Histogram1
#Data & Aesthetics
pl <- ggplot(movies,aes(x=rating))

#Geometry
pl2 <- pl+geom_histogram(binwidth = 0.1,color='red',fill='pink',alpha=0.5)

pl3 <- pl2 + xlab('Movie Rating') + ylab('Count')

print(pl3 + ggtitle('Movie analysis'))


#Histogram2
#to change the color based on count

pl <- ggplot(movies,aes(x=rating))

pl2 <- pl+geom_histogram(binwidth = 0.1,aes(fill=..count..))

pl3 <- pl2 + xlab('Movie Rating') + ylab('Count')

print(pl3 + ggtitle('Movie analysis'))
