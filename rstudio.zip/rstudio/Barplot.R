df <- mpg

#Barplot1
pl <- ggplot(df,aes(x=class))

print(pl + geom_bar(aes(fill=drv)))


#Barplot2
pl <- ggplot(df,aes(x=class))

print(pl + geom_bar(aes(fill=drv),position='dodge'))