library("ggplot2", lib.loc="/usr/local/lib/R/site-library")
library("data.table", lib.loc="/usr/local/lib/R/site-library")

df <- fread('/resources/data/Economist_Assignment_Data.csv',drop=1)
head(df)

pl <- ggplot(df,aes(x=CPI,y=HDI)) + geom_point(aes(color=factor(Region)),shape=1,size=4)
pl1 <- pl + geom_smooth(aes(group=1),method='lm',formula=y~log(x),se=F,color='red')


pointsToLabel <- c("Russia", "Venezuela", "Iraq", "Myanmar", "Sudan",
                   "Afghanistan", "Congo", "Greece", "Argentina", "Brazil",
                   "India", "Italy", "China", "South Africa", "Spane",
                   "Botswana", "Cape Verde", "Bhutan", "Rwanda", "France",
                   "United States", "Germany", "Britain", "Barbados", "Norway", "Japan",
                   "New Zealand", "Singapore")
pl2 <- pl1 + geom_text(aes(label = Country), color = "gray20", 
                       data = subset(df, Country %in% pointsToLabel),check_overlap = TRUE)
pl3 <- pl2 + theme_bw()

pl4 <- pl3 + scale_x_continuous(name = 'Corruption Perceptions Index', limits = c(0.9,10.5),breaks = 1:10)
pl5 <- pl4 + scale_y_continuous(name = 'Human Development Index', limits = c(0,1), breaks = seq(0,1,0.2))
pl6 <- pl5 + ggtitle(label = 'Corruption and Human Development')

print(pl6)