df <- mtcars

#Boxplot1
pl <- ggplot(df,aes(x=factor(cyl),y=mpg))
pl2 <- pl + geom_boxplot()
print(pl2)

#Boxplot2
pl <- ggplot(df,aes(x=factor(cyl),y=mpg))
pl2 <- pl + geom_boxplot() + coord_flip()
print(pl2)

#Boxplot3
pl <- ggplot(df,aes(x=factor(cyl),y=mpg))
pl2 <- pl + geom_boxplot(aes(fill=factor(cyl))) + theme_linedraw()
print(pl2)