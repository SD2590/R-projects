fullData <- read.csv("http://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data", header=F) #import

names(fullData) <- c("age", "workclass", "fnlwgt", "education", "educationnum", "maritalstatus", "occupation", "relationship", "race", "sex", "capitalgain", "capitalloss", "hoursperweek", "nativecountry", "response")

str(fullData)

fullData <- fullData[, c(15, 1:13)] # remove a factor with more than 31 levels.

str(fullData)

set.seed(100)

train <- base::sample (1:nrow(fullData), .8*nrow(fullData)) # training row indices

inputData <- fullData[train, ] # training data

testData <- fullData[-train, ] # test data


library(rpart)
rpartMod <- rpart(response ~ ., data = inputData, method = "class")  # build the model
printcp(rpartMod)  # print the cptable
rpart.plot::rpart.plot(rpartMod)

out <- predict(rpartMod) # predict probabilities

pred.response <- colnames(out)[max.col(out, ties.method = c("random"))] # predict response

mean(inputData$response != pred.response) # % misclassification error


out <- predict(rpartMod, testData) #predict test data
