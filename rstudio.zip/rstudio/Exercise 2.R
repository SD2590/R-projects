class (iris)  # get class

sapply (iris, class)  # get class of all columns

str (iris)  # structure

summary (iris)  # summary of airquality

head (iris)  # view the first 6 obs

rownames (iris)  # row names

colnames (iris)  # columns names

nrow (iris)  # number of rows

ncol (iris)  # number of columns

#Get the last 2 rows in last 2 columns from iris dataset
numRows <- nrow(iris)
numCols <- ncol(iris)
iris[(numRows-1):numRows,(numCols-1):numCols]

#Get rows with Sepal.Width > 3.5 
iris[iris$Sepal.Width > 3.5,]

#Get the rows with 'versicolor' species using subset() from iris
subset(iris, Species == "versicolor")

