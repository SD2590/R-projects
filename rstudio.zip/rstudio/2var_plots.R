library(ggplot2movies)

#2D bin chart

pl <- ggplot(movies,aes(x=year,y=rating))
pl2 <- pl + geom_bin2d(binwidth=c(3,1)) + scale_fill_gradient(low='blue',high='red')
print(pl2)


#2D density plot
pl <- ggplot(movies,aes(x=year,y=rating))
pl2 <- pl + geom_density_2d()
print(pl2)
