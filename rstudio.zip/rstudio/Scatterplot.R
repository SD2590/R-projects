df <- mtcars

#Scatterplot1
#Data & Aesthetics
pl <- ggplot(df,aes(x=wt,y=mpg))

#Geometrics
pl2 <- pl + geom_point(size=5)

print(pl2)


#Scatterplot2
#Data & Aesthetics
pl <- ggplot(df,aes(x=wt,y=mpg))

#Geometrics
pl2 <- pl + geom_point(aes(size=hp))

print(pl2)


#Scatterplot3
#Data & Aesthetics
pl <- ggplot(df,aes(x=wt,y=mpg))

#Geometrics
pl2 <- pl + geom_point(aes(size=factor(cyl)))

print(pl2)


#Scatterplot4
#Data & Aesthetics
pl <- ggplot(df,aes(x=wt,y=mpg))

#Geometrics
pl2 <- pl + geom_point(aes(shape=factor(cyl),color=factor(cyl)), size=3)

print(pl2)



#Scatterplot5
#Data & Aesthetics
pl <- ggplot(df,aes(x=wt,y=mpg))

#Geometrics
pl2 <- pl + geom_point(aes(shape=factor(cyl)), size=3, color='#808000')

print(pl2)


#Scatterplot6
#Data & Aesthetics
pl <- ggplot(df,aes(x=wt,y=mpg))

#Geometrics
pl2 <- pl + geom_point(aes(color=hp), size=3)
pl3 <- pl2 + scale_color_gradient(low='blue',high='red')

print(pl3)
