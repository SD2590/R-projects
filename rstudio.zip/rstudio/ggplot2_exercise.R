head(mpg)

#Histogram of hwy mpg values:
pl1 <- ggplot(mpg,aes(x=hwy))
pl2 <- pl1 + geom_histogram(binwidth = 1.5,fill='#f6655d',alpha=0.5)
print(pl2)

#Barplot of car counts per manufacturer with color fill defined by cyl count
pl1 <- ggplot(mpg,aes(x=manufacturer))
pl2 <- pl1 + geom_bar(aes(fill=factor(cyl)))
print(pl2)

head(txhousing)

#Create a scatterplot of volume versus sales
pl1 <- ggplot(txhousing,aes(x=sales,y=volume))
pl2 <- pl1 + geom_point(alpha=0.5,color='blue') 
pl3 <- pl2 + geom_smooth(color='red')
print(pl3)
