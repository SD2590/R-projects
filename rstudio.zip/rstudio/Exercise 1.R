#Getting square root of value
sqrt(729)

#Assigning numeric value and converting to character
b = 1947.0
b
b <- as.character(b)
print (b)

#Get working directory
getwd()

#create new environment
myEnv <- new.env()

#create numeric vector
num <- c(1:6)
num
class(num)

#create mixed vector
mixed <- c(1,'a',2,'b')
mixed
class(mixed)

# init character vector
charVec <- character(26)
charVec
charVec[1] <- "a"
charVec


#vector operations
States <- c("Haryana", "Gujarat", "Kerala", "Maharastra", "Orissa")
States
length(States)
States[c(1,2)]
States[3:4]
sort(States)
sort(States, decreasing = TRUE)

# because of the presence of 'a' character, the numbers are converted to characters as well.
out <- c(rep('a', 2), seq(1, 5), seq(7, 11, by=2))
out

#show without NA
inp <- c(1, 2, NA, 4)
inp
inp[!is.na(inp)]
inp





