install.packages("leaflet")
install.packages("htmlwidgets")
install.packages("IRdisplay")

library(leaflet)
library(htmlwidgets)
library(IRdisplay)

download.file("https://ibm.box.com/shared/static/9sfgqavy3bvr9epihw87p7x7vcpfywjn.txt",
              destfile = "/resources/data/countries.txt", quiet = TRUE)
download.file("https://ibm.box.com/shared/static/9u5rrzdlzalsbjewkmqqho4ohoe13g82.csv",
              destfile = "/resources/data/energy.csv", quiet = TRUE)

#Creating a map widget
m <- leaflet() %>%
  addTiles() %>%  # Add default OpenStreetMap map tiles
  addMarkers(lng=174.768, lat=-36.852, popup="The birthplace of R")
m  # Print the map
