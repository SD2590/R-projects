chocolate_df <- flavors_of_cacao
str(chocolate_df)

#Data Cleaning#
chocolate_df <- chocolate_df[-1,] #to remove first row from dataframe which has the column names
head(chocolate_df)
names(chocolate_df)
install.packages("tidyverse")
library(tidyverse)

names(chocolate_df) <- gsub("[[:space:]+]", "_", names(chocolate_df))#get rid of blanks in column names
chocolate_df <- type_convert(chocolate_df)

chocolate_df$Cocoa_Percent <- sapply(chocolate_df$Cocoa_Percent, function(x) gsub("%", "", x)) #remove % from Cocoa_Percent
chocolate_df <- type_convert(chocolate_df)
str(chocolate_df)
########################################################################################################################
# return a data_frame with the mean and sd of the Rating column, from the chocolate
# dataset in it
chocolate_df %>%
  summarise(averageRating = mean(Rating),
            sdRating = sd(Rating))

# Return the average and sd of ratings by the year a rating was given
chocolateData %>%
  group_by(Review_Date) %>%
  summarise(averageRating = mean(Rating),
            sdRating = sd(Rating))

# draw a plot with "Review_Date" as the x axis and "Rating" as the y axis, add a point for each data point, move each point slightly so they don't overlap and add a smoothed line (lm = linear model)
ggplot(chocolate_df,aes(x=Review_Date,y=Rating)) 
  + geom_point() 
  + geom_jitter() 
  + geom_smooth(method = 'lm')

# draw a plot with "Review_Date" as the x axis and "Rating" as the y axis, add a point for each data point, move each point slightly so they don't overlap and add a smoothed line (lm = linear model). Encode Cocoa_Percent as color.
ggplot(chocolate_df, aes(x= Review_Date, y = Rating, color = Cocoa_Percent)) + 
  geom_point() + 
  geom_jitter() +
  geom_smooth(method = 'lm')

# plot the relationship between cocoa percentage and ratings 
ggplot(chocolate_df,aes(x=Cocoa_Percent, y=Rating)) +
        geom_point(aes(colour=factor(Cocoa_Percent))) +
        xlab("Cocoa Percent(%) ") + ylab("Chocolate Bar Rating") +
        ggtitle("Scattor plot of Cocoa Percent vs Chocolate Bar Rating") 

#which country produces the highest rate chocolate bars on average
loca <- group_by(chocolate_df,Company_Location)
good <- summarise(loca,  count=n(), 
                  rate1= mean(Rating))
good1 <- arrange(good, rate1)

ggplot(good1,aes(x=reorder(Company_Location,rate1), y=rate1)) +
        geom_point(aes(size=count, colour=factor(rate1)), alpha=1/2) +
        theme(axis.text.x = element_text(angle = 90, hjust = 1) , legend.position="none") +
        labs(x="Country", y="Mean Chocolate Rating", title="Chocolate Rating vs Country")

#Average rating for Cocoa percentage
cocoaPerc <- group_by(chocolate_df,Cocoa_Percent)
rateSumm <- summarise(cocoaPerc, count=n(),
                      rate2 = mean(Rating))
ggplot(rateSumm, aes(x=Cocoa_Percent,y=rate2)) +
  geom_point(aes(size=count, colour=factor(Cocoa_Percent))) +
  theme(legend.position="none") +
  labs(x="Cocoa Percent", y="Mean Chocolate Rating", title="Chocolate Rating vs Cocoa Percent")

#best rated chocolate
best_choco <- chocolate_df[which(chocolate_df$Rating > 4),]

ggplot(best_choco, aes(x=Broad_Bean_Origin, y=Rating, colour=Company_Location))+
        geom_bar(stat="identity") +
        labs(x="Bean Origin ", y="Rating score" , title="Best Chocolate Bar") 