setwd("/resources/data")  #set working directory
train_df <- read.csv("train.csv")  #read the csv file into a dataframe
test_df <- read.csv("test.csv")

str(train_df)  #check structure of the dataframe
str(test_df)  #check structure of the dataframe

any(is.na(train_df))  #check if any NA in the data
attach(train_df)
base::table(Survived)   #to get count
prop.table(base::table(Survived))  #to get proportion

base::table(Sex)   #to get count
prop.table(base::table(Sex))  #to get proportion

test_df$Survived <- rep(0,418)  #add 0 to new 'Survived' column

prop.table(base::table(Survived,Sex),2)  #to get proportion

test_df$Survived <- 0
test_df$Survived[test_df$Sex == 'female'] <- 1

summary(train$Age)

#add new column 'Child'
train_df$Child <- 0
train_df$Child[train_df$Age<18] <- 1

#create a table with both gender and age to see the survival proportions for different subsets
aggregate(Survived ~ Child + Sex, data=train_df, FUN=sum)
aggregate(Survived ~ Child + Sex, data=train_df, FUN=length)
aggregate(Survived ~ Child + Sex, data=train_df, FUN=function(X){sum(X)/length(X)})


#create new column for 'Fare2'
train_df$Fare2 <- '30+'
train_df$Fare2[train_df$Fare < 30 & train_df$Fare >= 20] <- '20-30'
train_df$Fare2[train_df$Fare < 20 & train_df$Fare >= 10] <- '10-20'
train_df$Fare2[train_df$Fare < 10] <- '<10'

#create a table with both gender and age to see the survival proportions for different subsets
aggregate(Survived ~  Fare2 + Pclass + Sex, data=train_df, FUN=function(X){sum(X)/length(X)})

test_df$Survived <- 0
test_df$Survived[test_df$Sex == 'female'] <- 1
test_df$Survived[test_df$Sex == 'female' & test_df$Pclass == 3 & test_df$Fare >= 20] <- 0


##############################################################################################
library(rpart)
library(rattle)
library(rpart.plot)
library(RColorBrewer)
fit <- rpart(Survived ~ Pclass + Sex + Age + SibSp + Parch + Fare + Embarked,
             data=train_df,
             method="class")

fancyRpartPlot(fit)
Prediction <- predict(fit, test_df, type = "class")
submit <- data.frame(PassengerId = test_df$PassengerId, Survived = Prediction)
write.csv(submit, file = "firstdtree.csv", row.names = FALSE)

